#ifndef JOC_H
#define JOC_H

#include "Definicions.h"

class joc
{
public:
	joc(Tauler m_tauler, Figura m_figura)
	{
		m_tauler = tauler;
		m_figura = figura;
	}
	void inicialitza(const string& nomFitxer);
	bool giraFigura(DireccioGir direccio);
	bool mouFigura(int dirX);
	int baixaFigura();
	void escriuTauler(const string& nomFitxer);
private:
	Tauler m_tauler;
	Figura m_figura;
	void actualitzarTauler(int x1, int y1);
	void borrarFigura(int x1, int y1);
	void afegirFigura();
};
