#include "tauler.h"

ifstream& operator>>(ifstream& ifs, Tauler& p)
{
	for (int j = 0; j < 8; j++) {
		for (int i = 0; i < 0; i++) {
			ifs >> p.setTauler[j][i];
		}
		ifs >> endl;
	}
	return ifs;
}

ofstream& operator<<(ofstream& ofs, Tauler& c)
{
	for (int j = 0; j < 8; j++) {
		for (int i = 0; i < 0; i++) {
			ofs << c.tauler[j][i];
		}
		ofs << endl;
	}
	return ofs;
}

int Tauler::eliminarFiles(const Figura& figura)
{
    int numFilasEliminadas = 0;
    for (int fila = 0; fila < N_FILES; ++fila) {
        if (filaPlena(fila)) {
            borrarFila(fila);
            igualarFiles(fila, fila - 1);
            ++numFilasEliminadas;
        }
    }
    return numFilasEliminadas;
}

void Tauler::borrarFila(int fila)
{
    for (int i = fila; i > 0; --i) {
        for (int j = 0; j < N_COLUMNES; ++j) {
            m_tauler[i][j] = m_tauler[i - 1][j];
        }
    }
    for (int j = 0; j < N_COLUMNES; ++j) {
        m_tauler[0][j] = COLOR_NEGRE;
    }
}

bool Tauler::filaBuida(int fila) const
{
    for (int j = 0; j < N_COLUMNES; ++j) {
        if (m_tauler[fila][j] != COLOR_NEGRE) {
            return false;
        }
    }
    return true;
}

bool Tauler::filaPlena(int fila) const
{
    for (int j = 0; j < N_COLUMNES; ++j) {
        if (m_tauler[fila][j] == COLOR_NEGRE) {
            return false;
        }
    }
    return true;
}

void Tauler::igualarFiles(int f1, int f2)
{
    for (int j = 0; j < N_COLUMNES; ++j) {
        m_tauler[f1][j] = m_tauler[f2][j];
    }
}


bool Tauler::comprovarGir(const Figura& figura, DireccioGir direccion) const
{
    Figura figuraSimulada = figura;
    figuraSimulada.girarFigura(direccion);

    int altura = figuraSimulada.getAltura();
    int amplada = figuraSimulada.getAmplada();
    int fila = figuraSimulada.getFila();
    int columna = figuraSimulada.getColumna();

    if (columna < 0 || columna + amplada > N_COLUMNES || fila + altura > N_FILES) {
        return false; 
    }

    for (int i = 0; i < altura; ++i) {
        for (int j = 0; j < amplada; ++j) {
            if (figuraSimulada.getTauler(i, j) != NO_FIGURA) {
                if (m_tauler[fila + i][columna + j] != NO_FIGURA) {
                    return false;
                }
            }
        }
    }

    return true;
}


bool Tauler::comprovarMov(const Figura& figura, int dirX) const
{
    Figura figuraSimulada = figura;
    figuraSimulada.horitzontal(dirX);

    int altura = figuraSimulada.getAltura();
    int amplada = figuraSimulada.getAmplada();
    int fila = figuraSimulada.getFila();
    int columna = figuraSimulada.getColumna();

    if (columna < 0 || columna + amplada > N_COLUMNES) {
        return false;
    }

    for (int i = 0; i < altura; ++i) {
        for (int j = 0; j < amplada; ++j) {
            if (figuraSimulada.getTauler(i, j) != NO_FIGURA) {
                if (m_tauler[fila + i][columna + j] != NO_FIGURA) {
                    return false;
                }
            }
        }
    }

    return true;
}

void Tauler::eliminarFila(int fila)
{
        for (int i = fila; i > 0; --i) {
            for (int j = 0; j < N_COLUMNES; ++j) {
                m_tauler[i][j] = m_tauler[i - 1][j];
            }
        }
        for (int j = 0; j < N_COLUMNES; ++j) {
            m_tauler[0][j] = NO_FIGURA;
        }
    }
}