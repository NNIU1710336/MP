#include <iostream>
#include <joc.h>

using namespace std;

void joc::inicialitza(const string& nomFitxer)
{
	ifstream fitxer;
	fitxer.open("nomFitxer.txt")
	fitxer >> tipus >> fila >> columna >> gir;
	while (!fitxer.eof())
	{
		for (int i = 0; i < 8; i++)
		{
			for (int j = 0; j < 8; j++)
			{
				fitxer >> getTauler[i][j];
			}
			endl;
		}
	}
	fitxer.close;
}

void joc::AfegeixFitxa(ColorFigura tauler[][])
{
	getTauler[3][1] = 3;
	getTauler[3][2] = 3;
	getTauler[3][3] = 3;
	getTauler[4][2] = 3;
}

void joc::escriuTauler(const string& nomFitxer)
{
	ofstream fitxer;
	AfegeixFitxa;
	fitxer.open("nomFitxer.txt")
		while (!fitxer.eof())
		{
			for (int i = 0; i < 8; i++)
			{
				for (int j = 0; j < 8; j++)
				{
					fitxer << getTauler[i][j];
				}
				endl;
			}
	
		}
	fitxer.close;
}
void joc::mouFigura(int dirX)
{
	Figura figuraActual = m_figura;
	figuraActual.MouFiguraHoritzontal(dirX);
	if (m_tauler.comprovarMov(figuraActual, 0)) {
		m_figura = figuraActual;
	}
}

int joc::baixaFigura()
{
	Figura figuraActual = m_figura;

	if (m_tauler.comprovarMov(figuraActual, 1)) {
		figuraActual.baixar(1);
		m_figura = figuraActual;
		return 1;
	}
	else {
		afegirFigura();
		return 0;
	}
}


void joc::giraFigura
{
	bool girCorrecte;
	Figura figuraGirada = m_figura;
	if (m_tauler.comprovarGiro(figuraGirada, direccion)) {
		m_figura = figuraGirada;
		girCorrecte = true; 
	}

	girCorrecte = false;

	if (girCorrecte)
	{
		figuraGirada.girarFigura(direccion);
	}
}

void joc::eliminaFila
{
	for (int fila = 0; fila < N_FILES; ++fila) {
	bool filaPlena = true;
	for (int columna = 0; columna < N_COLUMNES; ++columna) {
		if (m_tauler.getTauler()[fila][columna] == NO_FIGURA) {
			filaPlena = false;
			break;
		}
	}
	if (filaPlena) {
		m_tauler.eliminarFila(fila);
	}
}
}