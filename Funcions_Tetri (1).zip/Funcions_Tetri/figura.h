#ifndef FIGURA_H
#define FIGURA_H

#include "Definicions.h"

class Figura
{
public:
	Figura(int m_fila, int m_columna, int m_gir, int m_altura, int m_amplada, TipusFigura m_tipus, TipusFigura m_Matriu)
	{
		m_fila = fila;
		m_columna = columna;
		m_gir = gir;
		m_tipus = tipus;
		m_altura = altura;
		m_amplada = amplada;
		m_Matriu = { 0 };
	}
	void girarFigura(DireccioGir direccio);
	void moureFigura(int dirX);
	void baixar();
	Figura CaracteristiquesFigura(TipusFigura c, int fila, int columna, int gir);
	int getMatriu(int i, int j) const { return m_Matriu[i][j]; };
	int getFila{ return fila; };
	int getColumna{ return columna; };
	int getGir{ return gir; };
	ColorFigura getColor() const { return color; };
	TipusFigura getTipus{ return tipus };
	int getX() const { return x; };
	int getY() const { return y; };
	void setFila{ m_fila = fila };
	void setColumna{ m_columna = columna };
	void setGir{ m_gir = gir };
	void setTipus{ m_tipus = tipus };

private:
	int m_altura;
	int m_amplada;
	TipusFigura m_Matriu[N_FILES][N_COLUMNES];
	int m_fila;
	int m_columna;
	int m_gir;
	TipusFigura m_tipus;
	int m_x;
	int m_y;
};

ifstream operator>>(ifstream& ifs, Figura& c);
#endif
