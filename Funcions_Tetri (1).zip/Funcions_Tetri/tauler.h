#ifndef TAULER
#define TAULER
#include "Definicions.h"
#pragma once
#include "joc.h"
#include "figura.h"

class Tauler
{
public:
	Tauler() { m_tauler = { 0 }; };
	Figura CaracteristiquesFigura(const Figura& c);
	int eliminarFiles(const Figura& figura);
	bool comprovarGir(const Figura& figura, DireccioGir direccion) const;
	bool comprovarMov(const Figura& figura, int dirX) const;
	bool baixarFigura(const Figura& figura) const;
	ColorFigura getTauler() { return tauler; };
	void setTauler(int fila, int columna, ColorFigura valor) {
		if (fila >= 0 && fila < filas && columna >= 0 && columna < columnas)
		{
			m_tauler[fila][columna] = valor;
		}
	}
private:
	ColorFigura m_tauler[N_FILES][N_COLUMNES];
	void borrarFila(int fila);
	bool filaBuida(int fila) const;
	bool filaPlena(int fila) const;
	void igualarFiles(int f1, int f2);
};

ifstream& operator>>(const ifstream& input, const Tauler& tauler);
ofstream& operator<<(const ofstream& output, const Tauler& tauler);
#endif


