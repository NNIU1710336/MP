#include <iostream>
#include "tauler.h"
#include "figura.h"
using namespace std;

Figura Figura::CaracteristiquesFigura(TipusFigura c, int fila, int columna, int gir)
{
	switch (c) {

	case 1:
		altura =2;
		amplada=2;
		matriu =
		{
			(1,1,0,0),
			(1,1,0,0),
			(0,0,0,0),
			(0,0,0,0),
		}
		break;
	case 2:
		altura = 4;
		amplada = 1;
		matriu =
		{
			(0,1,0,0),
			(0,1,0,0),
			(0,1,0,0),
			(0,1,0,0),
		}
		break;

	case 3:
		altura = 2;
		amplada = 3;
		matriu =
		{
			(1,1,1,0),
			(0,1,0,0),
			(0,0,0,0),
			(0,0,0,0),
		}
		break;

	case 4:
		altura = 3;
		amplada = 2;
		matriu =
		{
			(1,0,0,0),
			(1,0,0,0),
			(1,1,0,0),
			(0,0,0,0),
		}
		break;

	case 5:
		altura = 3;
		amplada = 2;
		matriu =
		{
			(0,1,0,0),
			(0,1,0,0),
			(1,1,0,0),
			(0,0,0,0),
		}
		break;

	case 6:
		altura = 2;
		amplada = 3;
		matriu =
		{
			(1,1,0,0),
			(0,1,1,0),
			(0,0,0,0),
			(0,0,0,0),
		}
		break;


	case 7:
		altura = 2;
		amplada = 3;
		matriu =
		{
			(0,1,1,0),
			(1,1,0,0),
			(0,0,0,0),
			(0,0,0,0),
		}
		break;
	}
}

ifstream operator>>(ifstream& ifs, const Figura& c)
{
	TipusFigura figura;
	int columna, fila, gir;
	ifs >> figura >> fila >> columna >> gir;
	return ifs;
}

void Figura::MouFiguraHoritzontal(int dirX)
{
	m_columna += dirX;

	for (int i = 0; i < m_altura; ++i) {
		for (int j = 0; j < m_amplada; ++j) {
			if (m_Matriu[i][j] != NO_FIGURA) {
				m_Matriu[i][j + dirX] = m_Matriu[i][j];
				m_Matriu[i][j] = NO_FIGURA;
			}
		}
	}
}

void Figura::baixar()
{
	m_fila++;
}

void Figura::girarFigura(DireccioGir direccion)
{
	if (direccion == GIR_HORARI) {
		TipusFigura nuevaMatriu[N_FILES][N_COLUMNES];
		for (int i = 0; i < m_altura; ++i) {
			for (int j = 0; j < m_amplada; ++j) {
				nuevaMatriu[j][m_altura - 1 - i] = m_Matriu[i][j];
			}
		}
		for (int i = 0; i < m_amplada; ++i) {
			for (int j = 0; j < m_altura; ++j) {
				m_Matriu[i][j] = nuevaMatriu[i][j];
			}
		}
	}
	else {
		for (int i = 0; i < 3; ++i) {
			girarFigura(GIR_HORARI);
		}
	}
}
